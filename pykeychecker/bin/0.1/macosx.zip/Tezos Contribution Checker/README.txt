Before you run the app you'll need libsodium installed on your computer.

If you don't have homebrew please run this in your terminal to install it:

ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)" < /dev/null 2> /dev/null


After that please run this to install libsodium:

brew install libsodium


The binary should work after this.